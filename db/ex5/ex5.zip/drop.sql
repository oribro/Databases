DROP TABLE Offer cascade;
DROP TABLE Trip;
DROP TABLE Company;

