username: orib
Name: Ori Broda
ID: 308043447

CSS styles that I used:
1. font-family
2. font-size
3. color
4. background image
5. margin
6. padding
7. text-align
8. border-style
9. border-width
10. border-radius
11. box-shadow
12. radial-gradient

HTML tags that I used:
1. h1, h2
2. p
3. img
4. strong
5. a href
6. details
7. ol, li
8. cite
9. br
10. audio
11. time
 